
Project 1 Cella Rule 150
Team RedX==> by Sohrab Yeawary & Aria Askaryar

Date 02/28/2020
__________________________________________________________

Introduction:  

	This program is an is written in HTML, which is a Javascript adopted language used to create web pages and animations such as this one. 
	In this program we used HTML code to draw a 2D, 401 by 401 square grid which will  have all cells full states. 
	Cells are little squares that can be in two states either off or on, white or black. A generation is the lines on the y-axis.  
	Each cell lives on the grid which goes through each generation creating a new child based on where the parent was located on the previous generation. 
	As the cursor moves from cell to cell the grid and pixels change color, the project can also be stopped or reset by action taken. You can select through generation. 


ex)
	Gen 0: 000010000
	Gen 1: 000101000
	Gen 2: 001010100

for (int i = 0; i < cells.length; i++) {            //where the cell is looped 

 else fill(0);                        //determines if the cell is off or on (0 or 1)                        
for (int i = 0; i < cells.length; i++) {            //goes through all the cells in the array
   int left   = cell[i-1];                    //goes through the neighborhood
  int middle = cell[i];
  int right  = cell[i+1];
 
  int newstate = rules(left,middle,right);        //follows algorithm of previous steps
 
  cell[i] = newstate;                    //sets the cell state into new value
}

cells = newcells;                    //New generation begins


Project Reports:
Q1; We completed the visual adaptations and cleaned up the project since last status. Also finalizing the complete cycle of the cellular automaton.

Q2; By the second status I plan to complete more documentation and visual clean ups.

Q3; The only obstacle was our generations would not flow consistently however it was fixed.
